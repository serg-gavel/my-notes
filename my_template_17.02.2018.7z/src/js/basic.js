$(window).on('load', function () {
    var body = $('body');
    // if( /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent) ) {
    // 	body.addClass('ios');
    // } else{
    // 	body.addClass('web');
    // }
    body.removeClass('loaded');
});
var handler = function(){
	var height_footer = $('footer').height();
	var height_header = $('header').height();
	//$('.content').css({'padding-bottom':height_footer+40, 'padding-top':height_header+40});
	var viewport_wid = viewport().width;
	var viewport_height = viewport().height;
	if (viewport_wid <= 991) {
	}
};