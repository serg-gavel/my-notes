// updated 17.02.2018
const gulp = require('gulp'),
    htmlminify = require("gulp-html-minify"),
    cssmin = require('gulp-cssmin'),
    // rename = require('gulp-rename'),
    minify = require('gulp-minify'),
    browserSync = require('browser-sync'),
    sass = require('gulp-sass'),
    pug = require('gulp-pug'),
    imagemin = require('gulp-imagemin');
//gulp sass
gulp.task('sass', function () {
    return gulp.src('src/**/*.scss')
        .pipe(sass().on('error', sass.logError))
        .pipe(gulp.dest('src'))
        .pipe(browserSync.reload({stream: true}))
});
//gulp pug
gulp.task('pug', function() {
    return gulp.src('src/**/*.pug')
        .pipe(pug({pretty:true}))
        .pipe(gulp.dest('src'))
        .pipe(browserSync.reload({stream: true}))
});

gulp.task('browser-sync', function () {
    browserSync({
        server: {
            baseDir: 'src'
        },
        notify:false
    });
});
// gulp dev
gulp.task('dev', ['browser-sync', 'sass', 'pug'], function () {
    gulp.watch('src/**/*.scss', ['sass']);
    gulp.watch('src/*.html', browserSync.reload);
    gulp.watch('src/*.html', browserSync.reload);
    gulp.watch('src/**/*.css', browserSync.reload);
    gulp.watch('src/**/*.js', browserSync.reload);
    gulp.watch('src/**/*.pug', ['pug']);
});
// gulp build
gulp.task('build', function () {

    gulp.src('src/**/*.css')
        .pipe(cssmin())
        // .pipe(rename({suffix: '.min'}))
        .pipe(gulp.dest('dist'));
    gulp.src('src/**/*.js')
        .pipe(minify({
            ext:{
                src:'-debug.js',
                min:'.js'
            },
            exclude: ['tasks'],
            ignoreFiles: ['.combo.js', '-min.js']
        }))
        .pipe(gulp.dest('dist'));
    gulp.src('src/img/*')
        .pipe(imagemin())
        .pipe(gulp.dest('dist/img'));
    return gulp.src("./src/**/*.html")
        .pipe(htmlminify())
        .pipe(gulp.dest("dist"))
});